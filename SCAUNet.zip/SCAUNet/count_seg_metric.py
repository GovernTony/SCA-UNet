"""
作者：QTY
说明：用于计算分割结果pseudo与标签gt的dice，recall，pre，asd指标
日期：2024/3/6/10：58
"""
import copy
import os
import numpy as np
import pandas as pd
import SimpleITK as sitk
from scipy.ndimage import morphology
from scipy import stats




"""average surface distance"""#如何计算ASD相关的指标。
def surfd(pre, gt, tid=1, sampling=1, connectivity=1):
    pre=pre==tid   #make it boolean
    gt=gt==tid     #make it boolean

    if pre.shape != gt.shape:
        raise ValueError("Shape mismatch: prediction and ground truth must have the same shape.")

    input_1 = np.atleast_1d(pre.astype(np.bool_))
    input_2 = np.atleast_1d(gt.astype(np.bool_))

    conn = morphology.generate_binary_structure(input_1.ndim, connectivity)

    S = np.logical_xor(input_1,morphology.binary_erosion(input_1, conn))
    Sprime = np.logical_xor(input_2,morphology.binary_erosion(input_2, conn))

    dta = morphology.distance_transform_edt(~S,sampling)
    dtb = morphology.distance_transform_edt(~Sprime,sampling)

    sds = np.concatenate([np.ravel(dta[Sprime!=0]), np.ravel(dtb[S!=0])])
    return sds


"""dice coefficient"""
def count_dice(pre, gt, tid=1):
    pre=pre==tid   #make it boolean
    gt=gt==tid     #make it boolean
    pre=np.asarray(pre).astype(np.bool_)
    gt=np.asarray(gt).astype(np.bool_)

    if pre.shape != gt.shape:
        raise ValueError("Shape mismatch: prediction and ground truth must have the same shape.")

    intersection = np.logical_and(pre, gt)
    dsc=(2. * intersection.sum() + 1e-07) / (pre.sum() + gt.sum() + 1e-07)

    return dsc


def count_asd(pre, gt, tid=1, sampling=1, connectivity=1):
    sds = surfd(pre, gt, tid=tid, sampling=sampling, connectivity=connectivity)
    dis = sds.mean()
    return dis

"""sensitivity"""
def count_recall(pre, gt, tid=1):
    pre=pre==tid #make it boolean
    gt=gt==tid   #make it boolean
    pre=np.asarray(pre).astype(np.bool_)
    gt=np.asarray(gt).astype(np.bool_)

    if pre.shape != gt.shape:
        raise ValueError("Shape mismatch: prediction and ground truth must have the same shape.")

    intersection = np.logical_and(pre, gt)
    sen=(1.0*intersection.sum()+1e-07) / (gt.sum()+1e-07)

    return sen

"""positive predictive value"""
def count_pre(pre, gt, tid=1):
    pre=pre==tid #make it boolean
    gt=gt==tid   #make it boolean
    pre=np.asarray(pre).astype(np.bool_)
    gt=np.asarray(gt).astype(np.bool_)

    if pre.shape != gt.shape:
        raise ValueError("Shape mismatch: prediction and ground truth must have the same shape.")

    intersection = np.logical_and(pre, gt)
    ppv=(1.0*intersection.sum() + 1e-07) / (pre.sum()+1e-07)

    return ppv


def get_seg_metric(pre, gt):
    mask = (pre>0.5)
    gt = (gt>0.5)
    ASD = count_asd(mask, gt) #asd(mask, gt)
    DSC = count_dice(mask, gt)
    #HFD = dice(mask,gt)  #hd
    SEN = count_recall(mask, gt)
    PPV = count_pre(mask, gt)
    # RAVD = dice(mask,gt)

    return DSC,PPV,SEN,ASD

def count_mean95conf(dice_scores, n_iterations=1000):
    """
    使用Bootstrap方法计算Dice系数的95%置信区间

    参数:
    dice_scores (list): 一个包含每个样本的Dice系数的列表
    n_iterations (int): 重采样的次数

    返回:
    tuple: 返回95%置信区间的下界和上界
    """
    # 用于存储每次重采样后的Dice系数平均值
    bootstrap_means = []

    # 进行多次重采样
    for _ in range(n_iterations):
        # 从原始数据中进行重采样
        sampled_scores = np.random.choice(dice_scores, size=len(dice_scores), replace=True)

        # 计算重采样后的Dice系数平均值
        bootstrap_means.append(np.mean(sampled_scores))

    # 计算95%置信区间
    lower_bound = np.percentile(bootstrap_means, 2.5)
    upper_bound = np.percentile(bootstrap_means, 97.5)

    half_width = upper_bound - lower_bound

    return np.mean(bootstrap_means), half_width


def seg_metric_main(pred_root_path, gt_root_path='/home/q/codes/datasets/nnUNetv2/raw/Dataset002_Thymus100/labelsTs'):

    sample_list = [sample[: -7] for sample in os.listdir(gt_root_path)]

    log_dict = {'dice': [], 'pre': [], 'recall': [], 'ASD': []}  # 这里面有每个样本的这样值，对他们处理
    for sample in sample_list:
        print(sample)
        sample_gt_path = os.path.join(gt_root_path, sample + '.nii.gz')
        sample_pseudo_path = os.path.join(pred_root_path, sample + '.nii.gz')

        sample_gt = sitk.GetArrayFromImage(sitk.ReadImage(sample_gt_path))
        sample_pseudo = sitk.GetArrayFromImage(sitk.ReadImage(sample_pseudo_path))

        dsc, ppv, sen, asd = get_seg_metric(sample_pseudo, sample_gt)
        cur_sample_dict = {'Sample': sample, 'Dice': dsc, 'Pre': ppv, 'Recall': sen, 'ASD': asd}

        # 记录
        log_dict['dice'].append(cur_sample_dict['Dice'])
        log_dict['pre'].append(cur_sample_dict['Pre'])
        log_dict['recall'].append(cur_sample_dict['Recall'])
        log_dict['ASD'].append(cur_sample_dict['ASD'])

        # print(True)

        # cur_sample_df = pd.DataFrame([cur_sample_dict])
        # metrics_df = pd.concat([metrics_df, cur_sample_df], ignore_index=True)

    with open(os.path.join(pred_root_path, 'a_metrics.txt'), 'w') as f:
        for metric, metric_list in log_dict.items():
            mean_metric, conf95 = count_mean95conf(metric_list)  #  计算95置信度

            if metric != 'ASD':
                message = f'mean {metric}: {mean_metric * 100} +- {conf95 * 100}'
            else:
                message = f'mean {metric}: {mean_metric} +- {conf95}'

            f.write(message + '\n')
            print(message)

    # with open(os.path.join(pseudo_root_path, 'metrics.txt'), 'w') as f:
    #    for cur_line in metric_list:
    #        f.write(str(cur_line) + '\n')


def get_dice_p_value(vice_root_path, chef_root_path, gt_root_path='/home/q/codes/datasets/nnUNetv2/raw/Dataset002_Thymus100/labelsTs'):
    sample_list = [sample[: -7] for sample in os.listdir(gt_root_path)]

    metrics_dict_example = {'dice': [], 'pre': [], 'recall': [], 'ASD': []}  # 这里面有每个样本的这些值，对他们处理

    chef_dict = copy.deepcopy(metrics_dict_example)
    vice_dict = copy.deepcopy(metrics_dict_example)

    for idx, sample in enumerate(sample_list):
        print(f'{idx+1}/{len(sample_list)} {sample}')
        cur_gt_path = os.path.join(gt_root_path, sample + '.nii.gz')
        cur_vice_path = os.path.join(vice_root_path, sample + '.nii.gz')
        cur_chef_path = os.path.join(chef_root_path, sample + '.nii.gz')

        cur_gt = sitk.GetArrayFromImage(sitk.ReadImage(cur_gt_path))
        cur_vice_pred = sitk.GetArrayFromImage(sitk.ReadImage(cur_vice_path))
        cur_chef_pred = sitk.GetArrayFromImage(sitk.ReadImage(cur_chef_path))

        vice_dice, vice_pre, vice_recall, vice_asd = get_seg_metric(cur_vice_pred, cur_gt)
        chef_dice, chef_pre, chef_reacll, chef_asd = get_seg_metric(cur_chef_pred, cur_gt)

        chef_dict['dice'].append(chef_dice)
        chef_dict['pre'].append(chef_pre)
        chef_dict['recall'].append(chef_reacll)
        chef_dict['ASD'].append(chef_asd)

        vice_dict['dice'].append(vice_dice)
        vice_dict['pre'].append(vice_pre)
        vice_dict['recall'].append(vice_recall)
        vice_dict['ASD'].append(vice_asd)

    for metric in ['dice', 'pre', 'recall', 'ASD']:
        small_flag = False
        t_stat, p_value = stats.ttest_ind(chef_dict[metric], vice_dict[metric])
        if p_value <= 0.05:
            small_flag = True

        print(f'cur model {metric} p<0.05: {small_flag} p_value: {p_value}')




if __name__ == '__main__':
    # gt_root_path = '/media/q/research/code/datasets/nnUNet1/raw/nnUNet_raw_data/Task001_Thymus/labelsTs'
    # pseudo_root_path = '/home/q/codes/datasets/nnUNetv2/raw/Dataset001_Thymus/0.78022dnnunet'

    get_dice_p_value(vice_root_path='/media/q/research/code/datasets/nnUnet_Dataset/raw/Dataset001_Thymus_all_preprocess/0.8681 nnunet_no_deep_test_results_final')
    # mean = metrics_df.mean()
    # metrics_df.loc[-1] = mean
    # metrics_df.index = metrics_df.index + 1
    # metrics_df = metrics_df.sort_index()
    # 
    # metrics_df.iloc[0, 0] = 'mean'
    # 
    # metrics_df.to_csv('./result.csv', index=False)
    # print(metrics_df)