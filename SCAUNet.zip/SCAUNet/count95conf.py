import os
import numpy as np


def bootstrap_confidence_interval(dice_scores, n_iterations=1000):
    """
    使用Bootstrap方法计算Dice系数的95%置信区间

    参数:
    dice_scores (list): 一个包含每个样本的Dice系数的列表
    n_iterations (int): 重采样的次数

    返回:
    tuple: 返回95%置信区间的下界和上界
    """
    # 用于存储每次重采样后的Dice系数平均值
    bootstrap_means = []

    # 进行多次重采样
    for _ in range(n_iterations):
        # 从原始数据中进行重采样
        sampled_scores = np.random.choice(dice_scores, size=len(dice_scores), replace=True)

        # 计算重采样后的Dice系数平均值
        bootstrap_means.append(np.mean(sampled_scores))

    # 计算95%置信区间
    lower_bound = np.percentile(bootstrap_means, 2.5)
    upper_bound = np.percentile(bootstrap_means, 97.5)

    half_width = upper_bound - lower_bound

    return half_width, np.mean(bootstrap_means)


