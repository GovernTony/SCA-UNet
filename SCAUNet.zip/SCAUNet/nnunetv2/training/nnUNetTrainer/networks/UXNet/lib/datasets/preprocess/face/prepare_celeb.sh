#!/usr/bin/env bash

PYTHON="/data/anaconda/envs/pytorch1.6.0/bin/python"

# $PYTHON celebmask_label_generator.py
# $PYTHON celebmask_partition.py
$PYTHON celebmask_resize.py
